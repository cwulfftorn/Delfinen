/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Domainlogic;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author jojus1101
 */
public class Club {

    private ArrayList<Member> Memberlist = new ArrayList<Member>();
    Member m1 = new Member("Emma", "Parker", LocalDate.of(2004,5,2), "98872932","Strandvejen 7b", "ep@hotmail.com","050204-3898", "Junior-Passiv");
    
    public void Club(){
         Memberlist.add(m1);
    }
   

}
