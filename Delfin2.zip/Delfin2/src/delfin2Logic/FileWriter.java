/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package delfin2Logic;

import delfin2.Member;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

/**
 *
 * @author joach_000
 */
public class FileWriter {
    public static void writeFile(Member m, String file) throws FileNotFoundException, UnsupportedEncodingException
    {
        file = "DelfinMember.txt";
        try
        {
            PrintStream output = new PrintStream(new FileOutputStream(file, true));

            output.print(System.lineSeparator() + m);
        } catch (IOException ex)
        {
            System.out.println("Fejl");
        }
    }
   
}
