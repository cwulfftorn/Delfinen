/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package delfin2Logic;

import delfin2Logic.Member;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author jojus1101
 */
public class OpretMember {

        Member m1 = new Member("Emma", "Parker", "2004, 5, 2", "98872932", "Strandvejen 7b", "ep@hotmail.com", "050204-3898", "Junior-Passiv");
        Member m2 = new Member("John", "Doe", "1995, 3, 10", "73732727", "Lyngbyvej 34", "JD@hotmail,com", "100395-3212", "Senior-Aktiv");
        ArrayList<Member> List = new ArrayList<Member>();
        public void OpretMember(){
        List.add(m1);
        List.add(m2);
    }

}
