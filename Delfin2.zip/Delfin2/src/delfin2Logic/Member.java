/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package delfin2Logic;

import java.time.LocalDate;

/**
 *
 * @author jojus1101
 */
public class Member {
    private String FirstName;
    private String LastName;
    private String birth;
    private String PhoneNumber;
    private String adress;
    private String mail;
    private String CPR;
    private String status;

    public Member( String Fn, String Ln, String birth, String PhoneNumber, String Adress, String Mail, String CPR, String status) {
        this.FirstName = Fn;
        this.LastName = Ln;
        this.birth = birth;
        this.PhoneNumber = PhoneNumber;
        this.adress = Adress;
        this.mail = Mail;
        this.CPR = CPR;
        this.status = status;
        
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public String getBirth() {
        return birth;
    }

    public void setBirth(String birth) {
        this.birth = birth;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }

    public String getAdress() {
        return adress;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getCPR() {
        return CPR;
    }

    public void setCPR(String CPR) {
        this.CPR = CPR;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Member{" + "FirstName=" + FirstName + ", LastName=" + LastName + ", birth=" + birth + ", PhoneNumber=" + PhoneNumber + ", adress=" + adress + ", mail=" + mail + ", CPR=" + CPR + ", status=" + status + '}';
    }

    
    
}
