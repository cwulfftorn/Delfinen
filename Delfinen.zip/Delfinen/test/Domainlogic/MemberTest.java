
package Domainlogic;

import java.time.LocalDate;
import java.time.Month;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author jojus1101
 */
public class MemberTest {
    
    public MemberTest() {
    }

   
    @Test
    public void createMember() {
        Member m = new Member( "Emma","Parker",LocalDate.of(2004, 5, 2), "98431050", "nørrebro 7b", "ep@hotmail.com", "050204-0589", "Junior-Passiv");
        //Arrange data + act på konstruktør
        // Act  ved kald af konstruktør
        
        // Assert
        assertNotNull(m);
        assertEquals("Emma", m.getFirstName());
        assertEquals("Parker",m.getLastName());
        assertEquals(LocalDate.of(2004, 5, 2), m.getBirth());
        assertEquals("98431050", m.getPhoneNumber());
        assertEquals("nørrebro 7b", m.getAdress());
        assertEquals("ep@hotmail.com", m.getMail());
        assertEquals("050204-0589", m.getCPR());
        assertEquals("Junior-Passiv", m.getStatus());
        
                
    }
}
