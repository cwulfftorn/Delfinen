
package Domainlogic;

import java.time.LocalDate;

public class Member {
    
    private String CPR;
    private String FirstName;
    private String LastName;
    private LocalDate birth;
    private String mail;
    private String adress;
    private String status;
    private String PhoneNumber;

    public Member( String FirstName, String LastName, LocalDate birth, String PhoneNumber, String adress, String mail, String CPR, String status) {
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.birth = birth;
        this.PhoneNumber = PhoneNumber;
        this.adress = adress;
        this.mail = mail;
        this.CPR = CPR;
        this.status = status;
        
    }

    public String getCPR() {
        return CPR;
    }

    public void setCPR(String CPR) {
        this.CPR = CPR;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public LocalDate getBirth() {
        return birth;
    }

    public void setBirth(LocalDate birth) {
        this.birth = birth;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getAdress() {
        return adress;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String PhoneNumber) {
        this.PhoneNumber = PhoneNumber;
    }
    

}